//v.3.5 build 120822

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/
dhtmlXGridObject.prototype._key_events={k45_0_0:function(){this.editor||this.addRow((new Date).valueOf(),[],this.row.rowIndex)},k46_0_0:function(){this.editor||this.cells4(this.cell).setValue("")}};

//v.3.5 build 120822

/*
Copyright DHTMLX LTD. http://www.dhtmlx.com
To use this component please contact sales@dhtmlx.com to obtain license
*/